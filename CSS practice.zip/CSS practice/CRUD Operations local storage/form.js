//list ofuser from local storage
let userList = JSON.parse(localStorage.getItem("users"));
console.log(userList);

//set the local storage data to table
setTable();

function setTable() {
  const tbody = document.getElementById("tableBody");
  const newTbody = document.createElement('tbody');
  newTbody.setAttribute("id", "tableBody");
  tbody.parentNode.replaceChild(newTbody, tbody);
  
  for (let i = 0; i < userList.length; i++) {
    const user = userList[i];
    row = document.createElement("tr");

    // table cells for id, name, email, company, age, and image
    const idCell = document.createElement("td");
    idCell.textContent = user.id;

    const nameCell = document.createElement("td");
    nameCell.textContent = user.name;

    const emailCell = document.createElement("td");
    emailCell.textContent = user.email;

    const companyCell = document.createElement("td");
    companyCell.textContent = user.company;

    const ageCell = document.createElement("td");
    ageCell.textContent = user.age;

    const imageCell = document.createElement("td");
    const imageElement = document.createElement("img");
    imageElement.src = user.image;
    imageElement.classList.add("user-image");
    imageCell.appendChild(imageElement);

    // action buttons
    const actionCell = document.createElement("td");

    // edit button
    const editButton = document.createElement("span");
    editButton.textContent = "edit";
    editButton.classList.add("material-symbols-outlined", "edit");

    // delete button
    const deleteButton = document.createElement("span");
    deleteButton.textContent = "delete";
    deleteButton.classList.add("material-symbols-outlined", "delete");

    // add event listeners to icons
    editButton.addEventListener("click", function () {
      const row = this.closest("tr");
      editingRow = row;
      console.log(row);
      updateMode(row);
    });
    deleteButton.addEventListener("click", deleteUser);

    // append icons to action cell
    actionCell.appendChild(editButton);
    actionCell.appendChild(deleteButton);

    // append cells to  row
    row.appendChild(idCell)
    row.appendChild(imageCell);
    row.appendChild(nameCell);
    row.appendChild(emailCell);
    row.appendChild(companyCell);
    row.appendChild(ageCell);
    row.appendChild(actionCell);

    const table = document
      .getElementById("usertable")
      .getElementsByTagName("tbody")[0];
    table.appendChild(row);
  }
}


//encode image url to base 64
function encodeImageFileAsURL(element, callback) {
  let file = element.files[0];
  let reader = new FileReader();

  reader.onloadend = function () {
    let encodedURL = reader.result;
    callback(encodedURL);
  };

  reader.readAsDataURL(file);
}

//set the image source
function displayImage(element) {
  encodeImageFileAsURL(element, function (encodedURL) {
    let image = document.getElementById("output");
    image.src = encodedURL;
  });
}

// toggle between add and edit mode
let editMode = false;
let editingRow = null;

// function to switch to add mode
function addMode() {
  editMode = false;
  document.getElementById("userForm").reset();
  document.getElementById("output").src = "user.png";
  document.getElementById("submitBtn").value = "Add";
}

// function to swtich to edit mode
function updateMode(row) {
  editMode = true;
  // set the data from row
  const image = row.querySelector("td:nth-child(2) img").src;
  const name = row.querySelector("td:nth-child(3)").textContent;
  const email = row.querySelector("td:nth-child(4)").textContent;
  const company = row.querySelector("td:nth-child(5)").textContent;
  const age = row.querySelector("td:nth-child(6)").textContent;

  // set the data to the form inputs for updating
  document.getElementById("name").value = name;
  document.getElementById("email").value = email;
  document.getElementById("company").value = company;
  document.getElementById("age").value = age;
  document.getElementById("output").src = image;

  document.getElementById("submitBtn").value = "Update";
}

// function to update row with new data
function updateRow(row) {
  console.log(row);
  const name = document.getElementById("name").value;
  const email = document.getElementById("email").value;
  const company = document.getElementById("company").value;
  const age = document.getElementById("age").value;
  const image = document.getElementById("output").src;


  const id = editingRow.querySelector("td:nth-child(1)").textContent;
  const index = id-1;
  userList[index].name = name;
  userList[index].email = email;
  userList[index].company = company;
  userList[index].age = age;
  userList[index].image = image;

  editingRow = null;
}

// function to add the user
function addUpdate(event) {
  // prevents form submitting
  event.preventDefault();

  let imageurl = "";
  if (editMode) {
    imageurl = document.getElementById("output").src;
  } else {
    if (document.getElementById("image").files[0]) {
      imageurl = document.getElementById("output").src;
    } else {
      imageurl = "";
    }
  }
  const image = imageurl;
  const name = document.getElementById("name").value;
  const email = document.getElementById("email").value;
  const company = document.getElementById("company").value;
  const age = document.getElementById("age").value;

  // check if name is valid
  if (name.length < 3 || !/^[a-zA-Z\s]+$/.test(name)) {
    alert("Please enter a valid name!");
    return;
  }

  // check if email is valid
  if (!isValidEmail(email)) {
    alert("Please enter a valid email address!");
    return;
  }

  // function to check if email format is correct
  function isValidEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  }

  // check if age is valid
  if (isNaN(age) || age < 1) {
    alert("Please enter a valid age!");
    return;
  }

  // check if age is valid
  if (!image) {
    alert("Please select the image!");
    return;
  }

  if (editMode){
    updateRow(editingRow);
  }
  else{
    const user = {
      id : userList.length + 1,
      name: name,
      email: email,
      company: company,
      age: age,
      image: image
    }
    userList.push(user);
  }
  localStorage.setItem("users", JSON.stringify(userList));
  setTable();
  addMode();
}

// delete the user
function deleteUser() {
  // user for which the delete button is clicked
  const row = this.closest("tr");
  const id = row.querySelector("td:nth-child(1)").textContent;
  userList = userList.filter ((user) => user.id != id);
  localStorage.setItem("users", JSON.stringify(userList));
  console.log("deleted");
  setTable();
}

// add event listener to the form submission
document.getElementById("userForm").addEventListener("submit", addUpdate);